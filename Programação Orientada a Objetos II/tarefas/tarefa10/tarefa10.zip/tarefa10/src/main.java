import model.PessoaDAO;
import view.TelaPessoa;

public class main {
    public static void main(String[] args) {
        TelaPessoa p = new TelaPessoa();
        p.Menu();
    }
}
