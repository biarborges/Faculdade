create table pessoa(
	id integer primary key,
	nome varchar(100),
	cpf varchar (15),
	telefone varchar (15)
)