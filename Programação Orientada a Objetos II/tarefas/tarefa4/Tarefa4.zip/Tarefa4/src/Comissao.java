public interface Comissao {

    public double calculaComissao(double valor);
}
