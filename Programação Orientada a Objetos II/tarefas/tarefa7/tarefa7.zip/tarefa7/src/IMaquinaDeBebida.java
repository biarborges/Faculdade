public interface IMaquinaDeBebida {//fabrica abstrata

    ISuco entregarSuco();
    IRefrigerante entregarRefrigerante();
    IAgua entregarAgua();
}
