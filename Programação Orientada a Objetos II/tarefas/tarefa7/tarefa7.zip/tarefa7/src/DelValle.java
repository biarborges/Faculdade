public class DelValle implements ISuco{//produto concreto


    @Override
    public String pegar() {
        return "Suco Del Valle";
    }
}
