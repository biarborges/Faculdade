public interface ISuco {//produto abstrato

    public String pegar();
}
