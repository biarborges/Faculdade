public class CocaColaZero implements IRefrigerante{ //produto concreto

    @Override
    public String pegar() {
        return "Coca Zero";
    }
}
