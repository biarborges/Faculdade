public class CocaColaNormal implements IRefrigerante{//produto concreto


    @Override
    public String pegar() {
        return "Coca Normal";
    }
}
