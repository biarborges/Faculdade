public class SucoLaranja implements ISuco{
    @Override
    public String pegar() {
        return "Suco de Laranja";
    }
}
