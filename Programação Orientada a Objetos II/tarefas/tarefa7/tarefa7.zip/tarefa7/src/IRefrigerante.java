public interface IRefrigerante {//produto abstrato

    public String pegar();
}
