public class AguaCrystal implements IAgua{ //produto concreto
    @Override
    public String pegar() {
        return "Água Crystal";
    }




}
