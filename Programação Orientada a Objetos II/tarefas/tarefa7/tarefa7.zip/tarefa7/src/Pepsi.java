public class Pepsi implements IRefrigerante{//produto concreto


    @Override
    public String pegar() {
        return "Pepsi";
    }
}
