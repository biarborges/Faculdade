public interface IAgua { //produto abstrato

    public String pegar();
}
