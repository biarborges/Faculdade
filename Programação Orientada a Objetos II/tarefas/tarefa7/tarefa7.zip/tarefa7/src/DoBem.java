public class DoBem implements ISuco{//produto concreto


    @Override
    public String pegar() {
        return "Suco Do Bem";
    }
}
