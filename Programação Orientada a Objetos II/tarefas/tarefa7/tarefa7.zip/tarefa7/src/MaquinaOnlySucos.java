public class MaquinaOnlySucos implements IMaquinaDeBebida{
    @Override
    public ISuco entregarSuco() {
        return new SucoLaranja();
    }

    @Override
    public IRefrigerante entregarRefrigerante() {
        return null;
    }

    @Override
    public IAgua entregarAgua() {
        return null;
    }
}
