public class AguaDoBem implements Agua{
    @Override
    public String Pegar() {
        return "Agua Do Bem";
    }
}
