public class AguaCrystal implements Agua{

    @Override
    public String Pegar() {
        return "Agua Crystal";
    }
}
