public class Pepsi implements Refrigerante{
    @Override
    public String Pegar() {
        return "Pepsi";
    }
}
