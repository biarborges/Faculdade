public interface Refrigerante {
    public String Pegar();
}
