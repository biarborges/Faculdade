public interface Agua {
    public String Pegar();
}
