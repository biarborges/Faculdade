public class CocaNormal implements Refrigerante {

    @Override
    public String Pegar() {
        return "Coca Cola";
    }
}
