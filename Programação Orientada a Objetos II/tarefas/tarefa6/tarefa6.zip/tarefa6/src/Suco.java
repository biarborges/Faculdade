public class Suco implements Bebida{ //product concrete
    @Override
    public String tipoBebida() {
        return "Suco";
    }
}
