public abstract class MaquinaDeBebidas {//creator-pode ser abstract

    public abstract Bebida entregarBebida();

    /*Bebida bebida;

    public abstract Bebida criaBebida();

    public void novaBebida(){
        this.bebida=criaBebida();
    }

    public void entregarBebida(){
        this.bebida.tipoBebida();
    }*/

}
