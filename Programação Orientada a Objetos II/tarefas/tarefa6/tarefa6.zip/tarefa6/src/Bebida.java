public interface Bebida { //product
    public String tipoBebida();
}
