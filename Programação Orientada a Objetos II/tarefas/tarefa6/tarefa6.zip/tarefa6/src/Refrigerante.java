public class Refrigerante implements Bebida{ //product concrete
    @Override
    public String tipoBebida() {
        return "Refrigerante";
    }
}
